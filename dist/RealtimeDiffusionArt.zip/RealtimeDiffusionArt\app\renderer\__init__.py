"""Realtime proxy renderer."""
