"""Realtime proxy renderer."""
