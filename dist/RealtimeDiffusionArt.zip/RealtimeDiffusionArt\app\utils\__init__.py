"""Shared utility code."""
