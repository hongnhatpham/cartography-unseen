"""Shared utility code."""
