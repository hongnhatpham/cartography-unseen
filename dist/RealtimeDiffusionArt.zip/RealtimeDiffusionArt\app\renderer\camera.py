from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians, sin, tan

import numpy as np

from app.types import CameraSnapshot


def perspective(fov_y_degrees: float, aspect: float, near: float, far: float) -> np.ndarray:
    f = 1.0 / tan(radians(fov_y_degrees) * 0.5)
    matrix = np.zeros((4, 4), dtype=np.float32)
    matrix[0, 0] = f / aspect
    matrix[1, 1] = f
    matrix[2, 2] = (far + near) / (near - far)
    matrix[2, 3] = (2.0 * far * near) / (near - far)
    matrix[3, 2] = -1.0
    return matrix


def look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    forward = target - eye
    forward /= np.linalg.norm(forward)
    side = np.cross(forward, up)
    side /= np.linalg.norm(side)
    corrected_up = np.cross(side, forward)
    matrix = np.identity(4, dtype=np.float64)
    matrix[0, :3] = side
    matrix[1, :3] = corrected_up
    matrix[2, :3] = -forward
    matrix[:3, 3] = -matrix[:3, :3] @ eye
    return matrix


@dataclass(slots=True)
class Camera:
    """Free-flight camera; the renderer owns spawn placement and collision.

    Movement has no gravity or fixed eye height. The surrounding forms still
    define the space, and every look direction is also a movement direction.
    """

    position: np.ndarray
    yaw: float = 0.0
    pitch: float = 0.0
    # Wide enough that nearby panels converge hard toward the vanishing point.
    fov: float = 82.0
    near: float = 0.05
    # Stay inside the nearest edge of the moving 11x11x11 chunk window.
    far: float = 280.0

    @classmethod
    def create_default(cls) -> "Camera":
        # Logical world coordinates stay double precision so a long flight never
        # loses sub-unit movement at large chunk indices.
        return cls(position=np.zeros(3, dtype=np.float64))

    def reset(self) -> None:
        self.position[:] = (0.0, 0.0, 0.0)
        self.yaw = 0.0
        self.pitch = 0.0

    @property
    def forward(self) -> np.ndarray:
        yaw = radians(self.yaw)
        pitch = radians(self.pitch)
        return np.array(
            [sin(yaw) * cos(pitch), sin(pitch), -cos(yaw) * cos(pitch)], dtype=np.float64
        )

    @property
    def right(self) -> np.ndarray:
        yaw = radians(self.yaw)
        return np.array([cos(yaw), 0.0, sin(yaw)], dtype=np.float64)

    def rotate(self, delta_x: float, delta_y: float, sensitivity: float) -> None:
        self.yaw = (self.yaw + delta_x * sensitivity) % 360.0
        self.pitch = float(np.clip(self.pitch - delta_y * sensitivity, -88.0, 88.0))

    def fly(self, local_x: float, local_y: float, local_z: float, distance: float) -> None:
        """Move ``distance`` along a body-local direction.

        ``local_z`` runs along the full look direction, pitch included, so
        looking up and holding forward climbs. ``local_x`` strafes level and
        ``local_y`` rises and falls along world up, which is what keeps a
        deliberate ascent independent of where the gaze happens to point.
        """

        direction = (
            self.right * local_x
            + np.array([0.0, 1.0, 0.0], dtype=np.float64) * local_y
            + self.forward * local_z
        )
        length = float(np.linalg.norm(direction))
        if length > 0.0:
            self.position += direction / length * distance

    def snapshot(self, aspect: float = 1.0) -> CameraSnapshot:
        view = look_at(
            self.position,
            self.position + self.forward,
            np.array([0.0, 1.0, 0.0], dtype=np.float32),
        )
        projection = perspective(self.fov, aspect, self.near, self.far)
        return CameraSnapshot(
            view_matrix=view,
            projection_matrix=projection,
            position=self.position.copy(),
            rotation=np.array([self.pitch, self.yaw, 0.0], dtype=np.float32),
        )
